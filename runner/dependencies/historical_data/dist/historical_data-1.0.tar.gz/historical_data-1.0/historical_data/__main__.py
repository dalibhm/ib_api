import historical_data_server

historical_data_server.main()
