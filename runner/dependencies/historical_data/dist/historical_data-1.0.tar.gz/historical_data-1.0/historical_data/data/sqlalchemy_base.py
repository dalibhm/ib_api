from sqlalchemy.ext.declarative import declarative_base

SqlAlchemyBase = declarative_base()
