from distutils.core import setup

setup(name='log_service',
      version='1.0',
      author='Mohamed Ali Ben Hamouda',
      author_email='mohamedali.benhamouda@gmail.com',
      packages=['logger'],
      )
